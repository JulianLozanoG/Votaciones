<?php

/* 
 * Cliente: A&P Finca Raiz.
 * Creado por: Interactive group. Julián Lozano.
 * Fecha: 2017
 */

$mysqli = new mysqli('localhost', 'root', '', 'i_vote');
require 'funcs/funcs.php';

$errors = array();
$succes = array();
                    
?>
  <!DOCTYPE html>
  <head>
    <meta charset="utf-8">
    <title></title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/grid/estilos.css">
    
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    
    <script language="javascript">
    function recargar(code){	
            var valor_id = code;
            $("#recargado"+valor_id).html('<img src="carga.gif" />');
            $.post("recuento.php", { variable: valor_id }, function(data){
                    $("#recargado"+ valor_id).html(data);
            });			
    }
    </script>
  </head>
  <body>
    <header>
          
    <!-- Diseño de la barra de navegación -->    
    <nav class="navbar navbar-toggleable-sm navbar-light" style="background-color:#e5e0e1">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#nav-content" aria-controls="nav-content" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon "></span>
        </button>
        
        <!-- Brand -->
        <a class="navbar-brand col-xs-12 col-sm-8 col-md-9 col-lg-9" href="indexvotacion.php">
            
            <h1>IVote</h1> </a>
        
        <!-- Links -->
        <div class="collapse navbar-collapse col-xs-12 col-sm-8 col-md-9 col-lg-3" id="nav-content">   
        <ul class="navbar-nav mr-">
            
            <li class="nav-item">
                <a class="nav-link" href="logout.php">Cerrar Sesi&oacute;n</a>
            </li>
        </ul>
        </div>
    </nav>
    <!-- fin del diseño de la barra de navegación-->    
    
    </header>
      
    <!--Manejo de botones superiores para Crear, modificar y eliminar -->

    
    <div class="container-fluid">
      <section class="main row">
        <article class="col-xs-12 col-sm-8 col-md-9 col-lg-12">
            <div class="page-header clearfix">
                <h3 class="pull-left">Sistema de Votaci&oacute;n:</h3><br>
                <?php
                // Se incluye la clase de conexión
                require_once 'funcs/conexion.php';
                // Se arma la consulta para obtener todos los candidatos
                $sql = "SELECT can.Id_candidato Id_can, can.Nombre nom, can.Cedula ced, can.Genero gen, can.Fec_Nacimiento fec, can.Num_candidato num, can.Foto fot "
                      ."FROM candidatos can";
                
                if($result = $mysqli->query($sql)){
                    if($result->num_rows > 0){
                        echo "<br>";
                        echo "<table class='table table-bordered table-striped'>";
                            echo "<thead>";
                                echo "<tr>";
                                    echo "<th>Nombre Candidato</th>";
                                    echo "<th>N&uacute;mero Candidato</th>";
                                    echo "<th>Foto</th>";
                                    echo "<th>Acciones</th>";
                                echo "</tr>";
                            echo "</thead>";
                            echo "<tbody>";
                            while($row = $result->fetch_array()){
                                echo "<tr>";
                                    echo "<td>" . $row['nom'] . "</td>";
                                    echo "<td>" . $row['num'] . "</td>";
                                    echo '<td><img src="data:image/jpeg;base64,'.base64_encode($row['fot']).'"/></td>';
                                    echo "<td><center>";
                                    echo "<a href='recuento.php?id=". $row['Id_can'] ."'title='Votar' data-toggle='tooltip'><span><img src='images/vote.png' width='28px' height='28px'></span></a>";
                                        
                                    echo "</center></td>";
                                echo "</tr>";
                            }
                            echo "</tbody>";                            
                        echo "</table>";
                        $result->free();
                    } else{
                        echo "<p class='lead'><em>No hay registros.</em></p>";
                    }
                } else{
                    echo "ERROR: No es posible realizar la ejecución $sql. " . $mysqli->error;
                }

                // Close connection
                $mysqli->close();
                ?>

                  <?php 
                    echo resultBlockSucces($succes);
                    echo resultBlock($errors);
                  ?>
            </div>
            <div id="respuesta"></div>
        </article>        
      </section>      
    </div>
    <!-- Sección donde se muestra el resultado de la consulta-->
    
    <!-- Tether -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous">
    </script>
    
    <!-- JQuery -->
    <script src="js/jquery.js" charset="utf-8"></script>
    
    <!-- Bootstrap 4 Alpha JS -->
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous">
    </script>   
    <script src="js/bootstrap.min.js" charset="utf-8"></script>
  </body>

</html>
