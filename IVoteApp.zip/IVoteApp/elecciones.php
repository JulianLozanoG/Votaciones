<?php

/* 
 * Proyecto : IVote App
 */

$mysqli = new mysqli('localhost', 'root', '', 'i_vote');
require 'funcs/funcs.php';

$errors = array();
$succes = array();

if (!empty($_POST)){
    
    
    $usuario = ($_POST['usuario']);
    $nombre = $mysqli->real_escape_string($_POST['nombre']);
    $cedula = $mysqli->real_escape_string($_POST['cedula']);
    $genero = $mysqli->real_escape_string($_POST['genero']);
    $fec_nacimiento = $mysqli->real_escape_string($_POST['fec_nacimiento']);
    $password = $mysqli->real_escape_string($_POST['password']);
    $con_password = $mysqli->real_escape_string($_POST['con_password']);
    $email = $mysqli->real_escape_string($_POST['email']);    
    
    //var_dump($_POST);
}
//require('config.php');

$vote = $_REQUEST['vote'];

//gObtiene el contenido de un archivo txt
$filename = "poll_result.txt";
$content = file($filename);

//pContenido en un array
$array = explode("||", $content[0]);
$yes = $array[0];
$no = $array[1];

if ($vote == 0) {
  $yes = $yes + 1;
}

if ($vote == 1) {
    $no = $no + 1;
}

//insert votes to txt file
$insertvote = $yes."||".$no;
$fp = fopen($filename,"w");
fputs($fp,$insertvote);
fclose($fp);
?>
<h2>Resultado:</h2>
<table>
  <tr>
    <td>Si:</td>
    <td><img src="poll.gif" width='<?php echo(100*round($yes/($no+$yes),2)); ?>' height='20'> <?php echo(100*round($yes/($no+$yes),2)); ?>% </td>
  </tr>
  <tr>
    <td>No:</td>
    <td><img src="poll.gif" width='<?php echo(100*round($no/($no+$yes),2)); ?>' height='20'> <?php echo(100*round($no/($no+$yes),2)); ?>% </td>
  </tr>
</table>
<p>Total de votos: <?php echo ($no+$yes); ?></p>
<p><a href="index.php">Volver a votar</a></p>