CREATE TABLE IF NOT EXISTS `votacion` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Votos` int(11) DEFAULT '0',
  `Noticia` text CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

INSERT INTO `votacion` (`Id`, `Votos`, `Noticia`) VALUES
(1, 49, 'Ridley Scott desciende a los infiernos con un reparto de lujo'),
(2, 17, 'Una familia de Tokio: El cuento de nunca acabar'),
(3, 29, 'El director Colin Trevorrow revela nuevos detalles de Jurassic World'),
(4, 20, 'Bienvenidos al fin del mundo: Juerga hasta el fin'),
(5, 25, 'De tal padre, tal hijo: De palos y astillas');