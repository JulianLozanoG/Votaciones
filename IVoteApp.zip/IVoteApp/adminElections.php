<?php

/* 
 * Cliente: A&P Finca Raiz.
 * Creado por: Interactive group. Julián Lozano.
 * Fecha: 2017
 */

$mysqli = new mysqli('localhost', 'root', '', 'i_vote');
require 'funcs/funcs.php';

$errors = array();
$succes = array();

if (!empty($_POST)){
    $nombre = $mysqli->real_escape_string($_POST['nombre']);
    $cedula = $mysqli->real_escape_string($_POST['cedula']);
    $genero = $mysqli->real_escape_string($_POST['genero']);
    $fec_nacimiento = $mysqli->real_escape_string($_POST['fec_nacimiento']);
    $password = $mysqli->real_escape_string($_POST['password']);
    $con_password = $mysqli->real_escape_string($_POST['con_password']);
    $email = $mysqli->real_escape_string($_POST['email']);    
    
    //var_dump($_POST);  
}

                    
?>
  <!DOCTYPE html>
  <head>
    <meta charset="utf-8">
    <title></title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/grid/estilos.css">
  </head>
  <body>
    <header>
          
    <!-- Diseño de la barra de navegación -->    
    <nav class="navbar navbar-toggleable-sm navbar-light" style="background-color:#e5e0e1">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#nav-content" aria-controls="nav-content" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon "></span>
        </button>

        <!-- Brand -->
        <a class="navbar-brand col-xs-12 col-sm-8 col-md-9 col-lg-8" href="adminusers.php">
            
            <h1>IVote</h1> </a>
        
        <!-- Links -->
        <div class="collapse navbar-collapse col-xs-12 col-sm-8 col-md-9 col-lg-4" id="nav-content">   
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="adminusers.php">Administraci&oacute;n de usuarios</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="admincandidates.php">Candidatos</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="adminElections.php">Elecciones</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">Cerrar Sesi&oacute;n</a>
            </li>
        </ul>
        </div>
    </nav>
    <!-- fin del diseño de la barra de navegación-->    
    
    </header>
      
    <!--Manejo de botones superiores para Crear, modificar y eliminar -->

    
    <div class="container-fluid">
      <section class="main row">
        <article class="col-xs-12 col-sm-8 col-md-9 col-lg-12">
            <div class="page-header clearfix">
                <h3 class="pull-left">Registro de Elecciones</h3>
                <a href="createElections.php" class="btn btn-success pull-right">Agregar Elecci&oacute;n</a><br>
                <?php
                // Se incluye la clase de conexión
                require_once 'funcs/conexion.php';
                // Se arma la consulta para obtener todos los usuarios
                $sql = "SELECT elec.Id_Eleccion Idelec,elec.Nombre Nome, elec.Fec_ini Fecini, elec.Fec_fin Fecfin, elec.Estado Est"
                        . " FROM elecciones elec ";
                
                if($result = $mysqli->query($sql)){
                    if($result->num_rows > 0){
                        echo "<br>";
                        echo "<table class='table table-bordered table-striped'>";
                            echo "<thead>";
                                echo "<tr>";
                                    echo "<th>Nombre Elecci&oacute;n</th>";
                                    echo "<th>Fecha Inicial</th>";
                                    echo "<th>Fecha Final</th>";
                                    echo "<th>Estado</th>";
                                    echo "<th>Acciones</th>";
                                echo "</tr>";
                            echo "</thead>";
                            echo "<tbody>";
                            while($row = $result->fetch_array()){
                                echo "<tr>";
                                    echo "<td>" . $row['Nome'] . "</td>";
                                    echo "<td>" . $row['Fecini'] . "</td>";
                                    echo "<td>" . $row['Fecfin'] . "</td>";
                                    echo "<td>" . $row['Est'] . "</td>";
                                    echo "<td><center>";
                                        echo "<a href='updateElections.php?id=". $row['Idelec'] ."' title='Actualizar registro' data-toggle='tooltip'><span><img src='images/editar.png' width='28px' height='28px'></span></a> &nbsp;";
                                        echo "<a href='deleteElections.php?id=". $row['Idelec'] ."' title='Eliminar registro' data-toggle='tooltip'><span><img src='images/eliminar.png' width='28px' height='28px'></span></a>";
                                    echo "</center></td>";
                                echo "</tr>";
                            }
                            echo "</tbody>";                            
                        echo "</table>";
                        $result->free();
                    } else{
                        echo "<p class='lead'><em>No hay registros.</em></p>";
                    }
                } else{
                    echo "ERROR: No es posible realizar la ejecución $sql. " . $mysqli->error;
                }

                // Close connection
                $mysqli->close();
                ?>

                  <?php 
                    echo resultBlockSucces($succes);
                    echo resultBlock($errors);
                  ?>
            </div>
        </article>        
      </section>      
    </div>
    <!-- Sección donde se muestra el resultado de la consulta-->
    
    <!-- Tether -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous">
    </script>
    
    <!-- JQuery -->
    <script src="js/jquery.js" charset="utf-8"></script>
    
    <!-- Bootstrap 4 Alpha JS -->
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous">
    </script>   
    <script src="js/bootstrap.min.js" charset="utf-8"></script>
  </body>

</html>
