-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:8889
-- Tiempo de generación: 18-09-2017 a las 03:18:58
-- Versión del servidor: 5.6.35
-- Versión de PHP: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Base de datos: `i_vote`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `candidatos`
--

CREATE TABLE `candidatos` (
  `Id_Candidato` int(11) NOT NULL COMMENT 'Identificación por BD del candidato',
  `Cedula` int(11) NOT NULL COMMENT 'Número de cédula del candidato',
  `Nombre` varchar(100) DEFAULT NULL COMMENT 'Nombre del candidato',
  `Foto` blob COMMENT 'Foto del cnadidato, campo tipo Blob para el manejo de imagenes',
  `Genero` tinytext COMMENT 'Campo tipo tiny text para la descrioción del genero delc andidato como: M y F',
  `Fec_Nacimiento` datetime DEFAULT NULL COMMENT 'Campo tipo DATETIME para la descrición de la fecha de nacimiento del candidato.',
  `Num_candidato` int(11) DEFAULT NULL COMMENT 'Campo tipo INT para la descripción del número de candidato, el cual será unico'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Tabla para el registro de los candidatos';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `elecciones`
--

CREATE TABLE `elecciones` (
  `Id_Eleccion` int(11) NOT NULL COMMENT 'Campo para la identificación por BD de la elección',
  `Nombre` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT 'Este campo será el nombre de la elección',
  `Fec_ini` datetime DEFAULT NULL COMMENT 'Fecha inicial de la elección',
  `Fec_fin` datetime DEFAULT NULL COMMENT 'Fecha final de la elección',
  `Estado` tinyint(2) DEFAULT NULL COMMENT 'Campo para el registro de la información del estado de la elección'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Tabla para registrar la información de la elección';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `eleccion_cadidato`
--

CREATE TABLE `eleccion_cadidato` (
  `Id_Elec_cand` int(11) NOT NULL COMMENT 'Campo tipo INT para el manejo de la identificación por BD del registro',
  `Candidato_Id` int(11) NOT NULL COMMENT 'Llave foranea con la tabla Candidatos',
  `Eleccion_Id` int(11) NOT NULL COMMENT 'Llave foranea con la tabla de Elecciones',
  `Voto_Id` int(11) NOT NULL COMMENT 'Llave foranea con la tabla de Votos'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Tabla para el manejo de los resultados para cada elección';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `perfiles`
--

CREATE TABLE `perfiles` (
  `Id_Perfil` int(11) NOT NULL COMMENT 'Identificación por BD del registro',
  `Nombre` varchar(45) CHARACTER SET latin1 DEFAULT NULL COMMENT 'Nombre asociado al perfil',
  `Activo` tinyint(2) DEFAULT NULL COMMENT 'campo tipo tinyint para el manejo del estado como 1 o 0 '
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Tabla para el manejo de perfiles';

--
-- Volcado de datos para la tabla `perfiles`
--

INSERT INTO `perfiles` (`Id_Perfil`, `Nombre`, `Activo`) VALUES
(1, 'Administrador', 1),
(2, 'Votante', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `Id_Usuario` int(11) NOT NULL COMMENT 'Identificación por BD del usuario',
  `Nombre` varchar(100) DEFAULT NULL COMMENT 'Nombre del usuario',
  `Cedula` int(11) DEFAULT NULL COMMENT 'Cédula del usuario',
  `Genero` char(2) DEFAULT NULL COMMENT 'Campo tipo Tiny text para el manejo del genero como: M y F',
  `Fec_Nacimiento` date DEFAULT NULL COMMENT 'Campo fecha de nacimiento del usuario',
  `Password` varchar(150) DEFAULT NULL COMMENT 'Campo para registrar la contraseña del usuario',
  `Email` varchar(200) NOT NULL,
  `Perfil_Id` int(11) NOT NULL COMMENT 'Llave foranea para asociar el un perfil al usuario'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Tabla para el registro de los usuarios';

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`Id_Usuario`, `Nombre`, `Cedula`, `Genero`, `Fec_Nacimiento`, `Password`, `Email`, `Perfil_Id`) VALUES
(1, 'Julian Lozano', 1018463748, 'M', '1993-12-10', '1234', 'jalozanog93@hotmail.com', 1),
(2, 'Luisa Fernanda', 121563748, 'F', '1992-10-10', '123456', 'luisa.fernandez@gmail.com', 1),
(3, 'Diana Maria Lozano', 1019438456, 'F', '1994-12-29', '123', 'dianalozano@gmail.com', 2),
(4, 'angelica maria', 2147483647, 'F', '1991-10-08', 'ange', 'angelica.paez08@gmail.com', 2),
(5, 'angelica maria', 2147483647, 'F', '1991-10-08', 'ange', 'angelica.paez08@gmail.com', 2),
(6, 'david alexander', 2147483647, 'M', '1996-11-08', 'david', 'davidlozanogonzalez@gmail.com', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `votos`
--

CREATE TABLE `votos` (
  `Id_Voto` int(11) NOT NULL COMMENT 'Identificación por BD del voto',
  `Usuario_Id` int(11) DEFAULT NULL COMMENT 'LLave foranea con la tabla Usuarios',
  `Eleccion_Id` int(11) DEFAULT NULL COMMENT 'Llave forane con la tabla de elecciones',
  `Candidato_Id` int(11) DEFAULT NULL COMMENT 'Llave foranea con la tabla de Candidatos',
  `Estado` tinyint(2) DEFAULT NULL COMMENT 'Campo tipo tiny int para el manejo del estado del voto como: 1 y 0',
  `Fecha` datetime DEFAULT NULL COMMENT 'Campo tipo DATETIME para el manejo de la fecha de la votación'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Tabla para el regsitro de los votos';

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `candidatos`
--
ALTER TABLE `candidatos`
  ADD PRIMARY KEY (`Id_Candidato`),
  ADD UNIQUE KEY `Num_candidato_UNIQUE` (`Num_candidato`);

--
-- Indices de la tabla `elecciones`
--
ALTER TABLE `elecciones`
  ADD PRIMARY KEY (`Id_Eleccion`);

--
-- Indices de la tabla `eleccion_cadidato`
--
ALTER TABLE `eleccion_cadidato`
  ADD PRIMARY KEY (`Id_Elec_cand`),
  ADD KEY `Candidato_Id` (`Candidato_Id`),
  ADD KEY `Eleccion_Id` (`Eleccion_Id`),
  ADD KEY `Voto_Id` (`Voto_Id`);

--
-- Indices de la tabla `perfiles`
--
ALTER TABLE `perfiles`
  ADD PRIMARY KEY (`Id_Perfil`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`Id_Usuario`),
  ADD KEY `perfil_idx` (`Perfil_Id`);

--
-- Indices de la tabla `votos`
--
ALTER TABLE `votos`
  ADD PRIMARY KEY (`Id_Voto`),
  ADD KEY `Usuario_Id` (`Usuario_Id`),
  ADD KEY `Eleccion_Id` (`Eleccion_Id`),
  ADD KEY `Candidato_Id` (`Candidato_Id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `candidatos`
--
ALTER TABLE `candidatos`
  MODIFY `Id_Candidato` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Identificación por BD del candidato';
--
-- AUTO_INCREMENT de la tabla `elecciones`
--
ALTER TABLE `elecciones`
  MODIFY `Id_Eleccion` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Campo para la identificación por BD de la elección';
--
-- AUTO_INCREMENT de la tabla `eleccion_cadidato`
--
ALTER TABLE `eleccion_cadidato`
  MODIFY `Id_Elec_cand` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Campo tipo INT para el manejo de la identificación por BD del registro';
--
-- AUTO_INCREMENT de la tabla `perfiles`
--
ALTER TABLE `perfiles`
  MODIFY `Id_Perfil` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Identificación por BD del registro', AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `Id_Usuario` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Identificación por BD del usuario', AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT de la tabla `votos`
--
ALTER TABLE `votos`
  MODIFY `Id_Voto` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Identificación por BD del voto';
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `eleccion_cadidato`
--
ALTER TABLE `eleccion_cadidato`
  ADD CONSTRAINT `eleccion_cadidato_ibfk_1` FOREIGN KEY (`Candidato_Id`) REFERENCES `candidatos` (`Id_Candidato`),
  ADD CONSTRAINT `eleccion_cadidato_ibfk_2` FOREIGN KEY (`Eleccion_Id`) REFERENCES `elecciones` (`Id_Eleccion`),
  ADD CONSTRAINT `eleccion_cadidato_ibfk_3` FOREIGN KEY (`Voto_Id`) REFERENCES `votos` (`Id_Voto`);

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `perfil` FOREIGN KEY (`Perfil_Id`) REFERENCES `perfiles` (`Id_Perfil`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `votos`
--
ALTER TABLE `votos`
  ADD CONSTRAINT `votos_ibfk_1` FOREIGN KEY (`Usuario_Id`) REFERENCES `usuarios` (`Id_Usuario`),
  ADD CONSTRAINT `votos_ibfk_2` FOREIGN KEY (`Eleccion_Id`) REFERENCES `elecciones` (`Id_Eleccion`),
  ADD CONSTRAINT `votos_ibfk_3` FOREIGN KEY (`Candidato_Id`) REFERENCES `candidatos` (`Id_Candidato`);
