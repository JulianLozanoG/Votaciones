<?php
// Se incluye archivo de conexión
require_once 'funcs/conexion.php';
$erros = array();
$succes = array();
//$id = $_GET["id"];
// Se procesa el formulario de actualización cuando se envía el sumbit
if($_GET["id"]){
    
    // Se obtiene el valor escondido del ID del registro
    if (empty($_POST['nombre'])) { $param_nombre="";} else { $param_nombre=$_POST['nombre'];}
    if (empty($_POST['cedula'])) { $param_cedula="";} else { $param_cedula=$_POST['cedula'];}
    if (empty($_POST['genero'])) { $param_genero="";} else { $param_genero=$_POST['genero'];}
    if (empty($_POST['fecnacimiento'])) { $param_fecnacimiento="";} else { $param_fecnacimiento=$_POST['fecnacimiento'];}    
    if (empty($_POST['numcandidato'])) { $param_numcandidato="";} else { $param_numcandidato=$_POST['numcandidato'];}
    if (empty($_POST["foto"])) { $param_foto="";} else { $param_foto = base64_encode(file_get_contents($_FILES['imagen']['tmp_name']));}
   
    $id = $_GET["id"];

    // Se prepara la sentencia Update
    $sql = "UPDATE candidatos "
          ."SET Nombre= '".$param_nombre."', Cedula= ".$param_cedula.", Genero='".$param_genero."', Fec_Nacimiento='".$param_fecnacimiento."', Num_candidato=".$param_numcandidato.", Foto = ".$param_foto.""
          ." WHERE Id_Candidato=".$id."";    
    $result = $mysqli->query($sql);
    
    // Operador lógico para la ejecución de la inserción
    if($result ==true){
            // Registro actualizado, se envia a la página de administración
            $succes[] = "Se actualizo correctamente";
            header("location: adminCandidates.php");
            //echo resultBlock($succes);
            exit();
    }else{
            $errors[] = "Algo ocurrio inesperadamente, por favor intentar de nuevo despu&eacute;s.";
            //echo resultBlock($errors);
    }
    // Close connection
    //exit();   
}else{
        // URL doesn't contain id parameter. Redirect to error page
        header("location: error.php");
        exit();
    }
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title></title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/grid/estilos.css">
    
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <header>
          
    <!-- Diseño de la barra de navegación -->    
    <nav class="navbar navbar-toggleable-sm navbar-light" style="background-color:#e5e0e1">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#nav-content" aria-controls="nav-content" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon "></span>
        </button>

        <!-- Brand -->
        <a class="navbar-brand col-xs-12 col-sm-8 col-md-9 col-lg-8" href="adminusers.php">
            
            <h1>IVote</h1> </a>
        
        <!-- Links -->
        <div class="collapse navbar-collapse col-xs-12 col-sm-8 col-md-9 col-lg-4" id="nav-content">   
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="adminusers.php">Administraci&oacute;n de usuarios</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="admincandidates.php">Candidatos</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="adminElections.php">Elecciones</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">Cerrar Sesi&oacute;n</a>
            </li>
        </ul>
        </div>
    </nav>
    <!-- fin del diseño de la barra de navegación-->    
    </header>
    <div class="container">            
        <div class="card col-lg-6">
            <!-- Consulta para obtener los valores de los parámetros por usuario -->
            <?php 
            $sqlCandidatos = "SELECT * FROM candidatos "
                         . "WHERE Id_Candidato = ".$id."";                
            $resultC = $mysqli->query($sqlCandidatos);
            $resultCandidatos = mysqli_fetch_array($resultC);               
            ?>
            <!-- Fin de consulta -->
            <div class="page-header">
                <h2>Actualizar Registro.</h2>
            </div>                
            <form id="updateform" class="form-horizontal" role="form" action="<?php $_SERVER['PHP_SELF'] ?>" method="post" autocomplete="on">
                <div class="form-group">
                    <input type="text" name="nombre" class="form-control" placeholder="Ingrese el nombre completo" value="<?php echo $resultCandidatos['Nombre']; ?>" required>
                </div>
                <div class="form-group">
                    <input type="text" name="cedula" class="form-control" placeholder="Ingrese el n&uacute;mero de C&eacute;dula" value="<?php echo $resultCandidatos['Cedula']; ?>" required>
                </div>
                <div class="form-group">
                    <select name="genero" id="genero" class="form-control" required>
                        <option value="0">-- Seleccione el Genero --</option>
                        <option value="M">Masculino</option>
                        <option value="F">Femenino</option>   
                    </select>
                </div>
                <div class="form-group">
                    <input type="date" name="fecnacimiento" class="form-control" placeholder="Fecha de nacimmiento (YYYY-MM-DD)" value="<?php echo $resultCandidatos['Fec_Nacimiento']; ?>" required>
                </div>
                <div class="form-group">
                    <input type="text" name="numcandidato" class="form-control" placeholder="N&uacute;mero candidato" value="<?php echo $resultCandidatos['Num_candidato']; ?>" required>
                </div>                
                <div class="form-group">
                    <input type="file" name="foto" class="form-control" >
                </div>
                
                <input type="hidden" name="id" value="<?php echo $id; ?>"/>
                <input type="submit" class="btn btn-success" value="Modificar">&nbsp;
                <a href="adminCandidates.php" class="btn btn-danger">Cancelar</a>
            </form>
        </div>
    </div> 
     <!-- Fin de formulario de registro-->  
    <?php 
    $mysqli->close();
    ?>
    <!-- Tether -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous">
    </script>
    
    <!-- JQuery -->
    <script src="js/jquery.js" charset="utf-8"></script>
    
    <!-- Bootstrap 4 Alpha JS -->
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous">
    </script>   
    <script src="js/bootstrap.min.js" charset="utf-8"></script>
    <script>
    // Initialize tooltip component
    $(function () {
      $('[data-toggle="tooltip"]').tooltip()
    })

    // Initialize popover component
    $(function () {
      $('[data-toggle="popover"]').popover()
    })
    </script>
    
</body>
</html>