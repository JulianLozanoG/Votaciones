<?php
// Se incluye archivo de conexión
require_once 'funcs/conexion.php';
$erros = array();
$succes = array();
$id = $_GET["id"];
// Se procesa el formulario de actualización cuando se envía el sumbit

if($_GET["id"]){
    
    //Se prepara la sentencia SQL para realizar la eliminación del registro
    $sql = "DELETE FROM candidatos WHERE Id_Candidato = ".$id."";    
    $result = $mysqli->query($sql);
    //var_dump($result);
    if($result == true){
            // Registro eliminado, se envia a la página de administración
            $succes[] = "Se elimino el registro correctamente";
            header("location: adminCandidates.php");
            //echo resultBlock($succes);
            exit();
    }else{
            $errors[] = "Algo ocurrio inesperadamente, por favor intentar de nuevo despu&eacute;s.";
            //echo resultBlock($errors);
    }
    // Close connection
    //exit();   
}else{
        // URL cuando no se puede obtener el ID del registro
        header("location: error.php");
        exit();
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title></title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/grid/estilos.css">
    
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <header>
          
    <!-- Diseño de la barra de navegación -->    
    <nav class="navbar navbar-toggleable-sm navbar-light" style="background-color:#e5e0e1">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#nav-content" aria-controls="nav-content" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon "></span>
        </button>

        <!-- Brand -->
        <a class="navbar-brand col-xs-12 col-sm-8 col-md-9 col-lg-8" href="adminusers.php">
            
            <h1>IVote</h1> </a>
        
        <!-- Links -->
        <div class="collapse navbar-collapse col-xs-12 col-sm-8 col-md-9 col-lg-4" id="nav-content">   
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="adminusers.php">Administraci&oacute;n de usuarios</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="admincandidates.php">Candidatos</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="adminElections.php">Elecciones</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">Cerrar Sesi&oacute;n</a>
            </li>
        </ul>
        </div>
    </nav>
    <!-- fin del diseño de la barra de navegación-->    
    </header>
    
    <div class="container">
        <div class="card col-lg-6">
            <div class="page-header">
                <h2>Eliminar Registro</h2>
            </div>
            <form id = "deleteform" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <div class="alert alert-danger fade in">
                    <input type="hidden" name="id" value="<?php echo trim($_GET["id"]); ?>"/>
                    <p>Se encuentra seguro de realizar la eliminaci&oacute;n del registro:</p><br>
                    <p>
                        <input type="submit" value="SI" class="btn btn-danger">
                        <a href="adminCandidates.php" class="btn btn-default">NO</a>
                    </p>
                </div>
            </form>
        </div>
    </div>
    <!-- Fin de formulario de registro-->  
    <?php 
    $mysqli->close();
    ?>
    <!-- Tether -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous">
    </script>
    
    <!-- JQuery -->
    <script src="js/jquery.js" charset="utf-8"></script>
    
    <!-- Bootstrap 4 Alpha JS -->
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous">
    </script>   
    <script src="js/bootstrap.min.js" charset="utf-8"></script>
    <script>
    // Initialize tooltip component
    $(function () {
      $('[data-toggle="tooltip"]').tooltip()
    })

    // Initialize popover component
    $(function () {
      $('[data-toggle="popover"]').popover()
    })
    </script>    
</body>
</html>