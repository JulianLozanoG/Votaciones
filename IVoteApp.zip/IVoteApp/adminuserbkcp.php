<?php

/* 
 * Cliente: A&P Finca Raiz.
 * Creado por: Interactive group. Julián Lozano.
 * Fecha: 2017
 */

$mysqli = new mysqli('localhost', 'root', '', 'i_vote');
require 'funcs/funcs.php';

$errors = array();
$succes = array();

if (!empty($_POST)){
    $nombre = $mysqli->real_escape_string($_POST['nombre']);
    $cedula = $mysqli->real_escape_string($_POST['cedula']);
    $genero = $mysqli->real_escape_string($_POST['genero']);
    $fec_nacimiento = $mysqli->real_escape_string($_POST['fec_nacimiento']);
    $password = $mysqli->real_escape_string($_POST['password']);
    $con_password = $mysqli->real_escape_string($_POST['con_password']);
    $email = $mysqli->real_escape_string($_POST['email']);    
    
    //var_dump($_POST);
    
    if(isNull($nombre, $genero, $cedula, $fec_nacimiento, $email, $password, $con_password)){
        $errors[]= "Debe llenar todos los campos"; 
    }
    if(!isEmail($email)){
        $errors[]= "Dirección de correo invalida";
    }
    if(!validaPassword($password, $con_password)){
        $errors[]= "Las contraseñas no coinciden";
    }
    
    if(count($errors == 0)){        
        $registro = registraUsuario($nombre, $genero, $cedula, $fec_nacimiento, $email, $password);
        var_dump($registro);
        
        if($registro > 0 ){
            $succes[] = "Registro de usuario exitoso";
        }else {
            $errors[]= "Error al registrar el usuario";
            echo "Falló la preparación: (" . $errormysql . ") ";
        }
    }
}

                    
?>
  <!DOCTYPE html>
  <head>
    <meta charset="utf-8">
    <title></title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/grid/estilos.css">
    <link rel="stylesheet" href="css/font-awesome.css">
    <!-- Funciones para consultar usuarios-->
    <script>
    function showUsers (cedula,nombre){
        document.getElementById("interfazresultado").innerHTML = "";
        return;
    }
    </script>
    
  </head>
  <body>
    <header>
          
    <!-- Diseño de la barra de navegación -->    
    <nav class="navbar navbar-toggleable-sm navbar-light" style="background-color:#e5e0e1">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#nav-content" aria-controls="nav-content" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon "></span>
        </button>

        <!-- Brand -->
        <a class="navbar-brand" href="principal.php">
            
            <h1>IVote</h1> </a>
        
        <!-- Links -->
        <div class="collapse navbar-collapse" id="nav-content">   
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="adminusers.php">Administraci&oacute;n de usuarios</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="admincandidates.php">Candidatos</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="elections.php">Elecciones</a>
            </li>
        </ul>
        </div>
    </nav>
    
    <!-- fin del diseño de la barra de navegación-->    
    </header>
    <!--Manejo de botones superiores para Crear, modificar y eliminar -->
<!--    <div class="container">
        
        <ul class="nav nav-pills">
	
            <li class="nav-item">
            <a class="nav-link" href="#">HTML</a>
            </li>

            <li class="nav-item">
            <a class="nav-link" href="#">CSS</a>
            </li>

            <li class="nav-item">
            <a class="nav-link" href="#">JavaScript</a>
            </li>

            <li class="nav-item">
            <a class="nav-link" href="#">Preview</a>
            </li>

        </ul>
        
    </div>-->
    
    <div class="container">
      <section class="main row">
        <article class="col-xs-12 col-sm-8 col-md-9 col-lg-12">
            <div class="flotante"><h3>Registro de usuarios</h3><br>                 
                <form id="loginform" name="registro" method="post" action="<?php $_SERVER['PHP_SELF']?>">
                    <div style="margin-bottom: 15px" class="input-group">                                        
                    <input id="nombre" type="text" class="form-control" name="nombre" placeholder="nombre completo" required>                                        
                    </div>
                    <div style="margin-bottom: 15px" class="input-group">                                        
                    <input id="cedula" type="text" class="form-control" name="cedula" placeholder="Cedula" required>                                        
                    </div>
                    <div style="margin-bottom: 15px" class="input-group">                                        
                    <select name="genero" id="genero" class="form-control" required>
                        <option value="0">-- Seleccione el Genero --</option>
                        <option value="M">Masculino</option>
                        <option value="F">Femenino</option>
                    </select>
                    </div>
                    <div style="margin-bottom: 15px" class="input-group">                                        
                    <input id="fec_nacimiento" type="datetime" class="form-control" name="fec_nacimiento" placeholder="Fecha de nacimiento (YYYY-MM-DD)" required>                                        
                    </div>                    
                    <div style="margin-bottom: 15px" class="input-group">                                        
                    <input id="email" type="text" class="form-control" name="email" placeholder="Correo Electronico" required>                                        
                    </div>
                    <div style="margin-bottom: 15px" class="input-group">                                        
                    <input id="password" type="password" class="form-control" name="password" placeholder="Password" required>                                        
                    </div>
                    <div style="margin-bottom: 15px" class="input-group">                                        
                    <input id="con_password" type="password" class="form-control" name="con_password" placeholder="Confirmar password" required>                                        
                    </div>                    
                    <div style="margin-top:10px" class="form-group">
                    <div class="col-sm-12 controls">
                    <button id="btn-login" type="submit" class="btn btn-success">Registrar</a>
                    </div>
                    </div>
                </form>

                  <?php 
                    echo resultBlockSucces($succes);
                    echo resultBlock($errors);
                  ?>
            </div>
        </article>        
      </section>      
    </div>
    <!-- Sección donde se muestra el resultado de la consulta-->
    <div id="interfazresultado"></div>
    <!-- Tether -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous">
    </script>
    
    <!-- JQuery -->
    <script src="js/jquery.js" charset="utf-8"></script>
    
    <!-- Bootstrap 4 Alpha JS -->
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous">
    </script>   
    <script src="js/bootstrap.min.js" charset="utf-8"></script>
  </body>

</html>
