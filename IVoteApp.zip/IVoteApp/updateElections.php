<?php
// Se incluye archivo de conexión
require_once 'funcs/conexion.php';
$erros = array();
$succes = array();
//$id = $_GET["id"];
// Se procesa el formulario de actualización cuando se envía el sumbit
if($_GET["id"]){
            
    // Se obtiene el valor escondido del ID del registro
    if (empty($_POST['nombre'])) { $param_nombre="";} else { $param_nombre=$_POST['nombre'];}
    if (empty($_POST['fec_ini'])) { $param_fec_ini="";} else { $param_fec_ini=$_POST['fec_ini'];}
    if (empty($_POST['fec_fin'])) { $param_fec_fin="";} else { $param_fec_fin=$_POST['fec_fin'];}
    if (empty($_POST['estado'])) { $param_estado="";} else { $param_estado=$_POST['estado'];}
    
    $id = $_GET["id"];

    // Se prepara la sentencia Update
    $sql = "UPDATE elecciones "
          ."SET Nombre= '".$param_nombre."', Fec_ini= '".$param_fec_ini."', Fec_fin='".$param_fec_fin."', Estado=".$param_estado.""
          ." WHERE Id_Eleccion=".$id."";    
    $result = $mysqli->query($sql);
    
    // Operador lógico para la ejecución de la inserción
    if($result ==true){
            // Registro actualizado, se envia a la página de administración
            $succes[] = "Se actualizo correctamente";
            header("location: adminElections.php");
            //echo resultBlock($succes);
            exit();
    }else{
            $errors[] = "Algo ocurrio inesperadamente, por favor intentar de nuevo despu&eacute;s.";
            //echo resultBlock($errors);
    }
    // Close connection
    //exit();   
}else{
        // URL doesn't contain id parameter. Redirect to error page
        header("location: error.php");
        exit();
    }
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title></title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/grid/estilos.css">
    
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <header>
          
    <!-- Diseño de la barra de navegación -->    
    <nav class="navbar navbar-toggleable-sm navbar-light" style="background-color:#e5e0e1">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#nav-content" aria-controls="nav-content" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon "></span>
        </button>

        <!-- Brand -->
        <a class="navbar-brand col-xs-12 col-sm-8 col-md-9 col-lg-8" href="adminusers.php">
            
            <h1>IVote</h1> </a>
        
        <!-- Links -->
        <div class="collapse navbar-collapse col-xs-12 col-sm-8 col-md-9 col-lg-4" id="nav-content">   
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="adminusers.php">Administraci&oacute;n de usuarios</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="admincandidates.php">Candidatos</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="adminElections.php">Elecciones</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">Cerrar Sesi&oacute;n</a>
            </li>
        </ul>
        </div>
    </nav>
    <!-- fin del diseño de la barra de navegación-->    
    </header>
    <div class="container">            
        <div class="card col-lg-6">
            <!-- Consulta para obtener los valores de los parámetros por usuario -->
            <?php 
            $sqlElecciones = "SELECT * FROM elecciones "
                         . "WHERE Id_Eleccion = ".$id."";                
            $resultEleccion = $mysqli->query($sqlElecciones);
            $resultE = mysqli_fetch_array($resultEleccion);               
            ?>
            <!-- Fin de consulta -->
            <div class="page-header">
                <h2>Actualizar Registro.</h2>
            </div>                
            <form id="updateform" class="form-horizontal" role="form" action="<?php $_SERVER['PHP_SELF'] ?>" method="post" autocomplete="on">
                <div class="form-group cl-lg-6">
                    <div class="form-group">
                        <input type="text" name="nombre" class="form-control" placeholder="Ingrese el nombre completo" value="<?php echo $resultE['Nombre']; ?>" required>
                    </div>
                    <div class="form-group">
                        <input type="date" name="fec_ini" class="form-control" placeholder="Fecha inicial (YYYY-MM-DD)" value="<?php echo $resultE['Fec_ini']; ?>" required>
                    </div>
                    <div class="form-group">
                        <input type="date" name="fec_fin" class="form-control" placeholder="Fecha final (YYYY-MM-DD)" value="<?php echo $resultE['Fec_fin']; ?>" required>
                    </div>
                    <div class="form-group">
                        <select name="estado" id="estado" class="form-control" required>
                            <option value="1">Activo</option>
                            <option value="0">Inactivo</option>   
                        </select>
                    </div>

                    <input type="hidden" name="id" value="<?php echo $id; ?>"/>
                    <input type="submit" class="btn btn-success" value="Modificar">&nbsp;
                    <a href="adminElections.php" class="btn btn-danger">Cancelar</a>
                </div>
            </form>
        </div>
    </div> 
     <!-- Fin de formulario de registro-->  
    <?php 
    $mysqli->close();
    ?>
    <!-- Tether -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous">
    </script>
    
    <!-- JQuery -->
    <script src="js/jquery.js" charset="utf-8"></script>
    
    <!-- Bootstrap 4 Alpha JS -->
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous">
    </script>   
    <script src="js/bootstrap.min.js" charset="utf-8"></script>
    <script>
    // Initialize tooltip component
    $(function () {
      $('[data-toggle="tooltip"]').tooltip()
    })

    // Initialize popover component
    $(function () {
      $('[data-toggle="popover"]').popover()
    })
    </script>
    
</body>
</html>