
<!--
Cliente: A&P Finca Raiz.
Creado por: Interactive group. Julián Lozano.
Fecha: 2017
-->

<html>
  <head>
    <meta charset="utf-8">
    <title></title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/grid/estilos.css">
    <link rel="stylesheet" href="css/font-awesome.css">
    <!--<link rel="stylesheet" href="css/style.css">-->
  </head>
  <body>
    <header>
          
    <!-- Diseño de la barra de navegación -->    
    <nav class="navbar navbar-toggleable-sm navbar-light" style="background-color:#e5e0e1">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#nav-content" aria-controls="nav-content" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon "></span>
        </button>

        <!-- Brand -->
        <a class="navbar-brand" href="principal.php">
            
            <h1>IVote</h1> </a>
        
        <!-- Links -->
        <div class="collapse navbar-collapse" id="nav-content">   
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="adminusers.php">Administraci&oacute;n de usuarios</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="admincandidates.php">Candidatos</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="elections.php">Elecciones</a>
            </li>
        </ul>
        </div>
    </nav>
    
    <!-- fin del diseño de la barra de navegación-->    
    </header>

    <div class="container-fluid">
      <section class="main row">
        <article class="col-xs-12 col-sm-8 col-md-9 col-lg-8">          
            <p><h4>Sistema de votaciones IVote.<br> 
                <br>
                Se pueden registrar usuarios, candidatos y elecciones.
                Los usuarios podrán realizar   el proceso de votación, como tambien se registrarán los candidatos, los cuales estarán asociados a una elección en particular.</h4></p>
        </article>
        <article class="col-xs-12 col-sm-8 col-md-9 col-lg-4">          
            <img  src="images/votaciones.jpg" width="440px" height="300px">
        </article>
        
      </section>   
    </div>
      
    <!-- Tether -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous">
    </script>
    
    <!-- JQuery -->
    <script src="js/jquery.js" charset="utf-8"></script>
    
    <!-- Bootstrap 4 Alpha JS -->
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous">
    </script>   
    <script src="js/bootstrap.min.js" charset="utf-8"></script>
  </body>
 
</html>


