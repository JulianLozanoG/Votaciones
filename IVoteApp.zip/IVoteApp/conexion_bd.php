<?php
$con=mysqli_connect("localhost","root","password","base de datos");
if (mysqli_connect_errno())
{
	echo "Problemas de conexión: " . mysqli_connect_error();
}
?>