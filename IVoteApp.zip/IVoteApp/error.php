<!--
Proyecto: Ivote
-->
  <!DOCTYPE html>              
  <head>
    <meta charset="utf-8">
    <title></title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/grid/estilos.css">
    <link rel="stylesheet" href="css/font-awesome.css">
    <!-- Funciones para consultar usuarios-->
    <script>
    
    </script>
    
  </head>

    <header>
    <!-- Diseño de la barra de navegación -->    
    <nav class="navbar navbar-toggleable-sm navbar-light" style="background-color:#e5e0e1">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#nav-content" aria-controls="nav-content" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon "></span>
        </button>

        <!-- Brand -->
        <a class="navbar-brand col-xs-12 col-sm-8 col-md-9 col-lg-11" href="index.php">
            
            <h1>IVote</h1> </a>
        
        <!-- Links -->
        <div class="collapse navbar-collapse justify-content-end col-xs-12 col-sm-8 col-md-9 col-lg-1" id="nav-content">   
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">            
                <li class="nav-item">
                <a class="nav-link" href="logout.php">Cerrar Sesi&oacute;n</a>
                </li>
            </li>
        </ul>
        </div>
    </nav>
    
    <!-- fin del diseño de la barra de navegación-->    
    </header>

    <div class="container-fluid">
      <section class="main row">
        <article class="col-xs-12 col-sm-8 col-md-9 col-lg-8">          
            <p><h4>Error insesperado.<br> 
                <br>
                Perdon por las molestias, ocurrio un error inesperado, por favor contactarse con el administrador del sistema.</h4></p>
        </article>
        <article class="col-xs-12 col-sm-8 col-md-9 col-lg-4">          
            <img  src="images/error.jpg" width="440px" height="300px">
        </article>
        
      </section>   
    </div>
    
    <script src="js/jquery.js" charset="utf-8"></script>
    <script src="js/bootstrap.min.js" charset="utf-8"></script>
    <!-- Tether -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous">
    </script>
    
    <!-- JQeury -->
    <script src="js/jquery.js" charset="utf-8"></script>
    
    <!-- Bootstrap 4 Alpha JS -->
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous">
    </script>   
    <script src="js/bootstrap.min.js" charset="utf-8"></script>
    
    <!-- Initialize Bootstrap functionality -->
    <script>
    // Initialize tooltip component
    $(function () {
      $('[data-toggle="tooltip"]').tooltip()
    })

    // Initialize popover component
    $(function () {
      $('[data-toggle="popover"]').popover()
    })
    </script>
    
  </body>

</html>


