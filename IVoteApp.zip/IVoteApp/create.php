<?php
// Se incluye la clase para efectuar la conexión
require_once 'funcs/conexion.php';
$errors = array();
// Formulario de proceso cuando se envia la información
if($_SERVER["REQUEST_METHOD"] == "POST"){

    $param_nombre = $_POST["nombre"];
    $param_cedula = $_POST["cedula"];
    $param_genero = $_POST["genero"];
    $param_fecnacimiento = $_POST["fecnacimiento"];
    $param_password = $_POST["password"];
    $param_email = $_POST["email"];
    $param_perfil = $_POST["perfil"];
    
    // Se realiza la sentencia SQL para el Insert
    $sql = "INSERT INTO usuarios "
        . "(Nombre, Cedula, Genero, Fec_Nacimiento, Password, Email, Perfil_Id) "
        . "VALUES ('".$param_nombre."', ".$param_cedula.", '".$param_genero."', '".$param_fecnacimiento."', '".$param_password."', '".$param_email."', ".$param_perfil.")";
    $result = $mysqli->query($sql);
    
    // Operador lógico para la ejecución de la inserción
    if($result ==true){
        // Sí el registro se creó correctamente, se redirige a la página de adminuser.php
        
        header("location: adminusers.php");
        exit();
    } else{
//        echo "Errormessage: %s\n", $mysqli->error;
        $errors[]= "Por favor efectuar el registro nuevamente.";
    }
    echo resultBlock($errors);
    // Cierre del statment
    $stmt->close();
}

?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title></title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/grid/estilos.css">
    
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <header>
          
    <!-- Diseño de la barra de navegación -->    
    <nav class="navbar navbar-toggleable-sm navbar-light" style="background-color:#e5e0e1">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#nav-content" aria-controls="nav-content" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon "></span>
        </button>

        <!-- Brand -->
        <a class="navbar-brand col-xs-12 col-sm-8 col-md-9 col-lg-8" href="adminusers.php.php">
            
            <h1>IVote</h1> </a>
        
        <!-- Links -->
        <div class="collapse navbar-collapse col-xs-12 col-sm-8 col-md-9 col-lg-4" id="nav-content">   
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="adminusers.php">Administraci&oacute;n de usuarios</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="admincandidates.php">Candidatos</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="elections.php">Elecciones</a>
            </li>
        </ul>
        </div>
    </nav>
    <!-- fin del diseño de la barra de navegación-->    
    </header>
    <!-- Formulario de registro de usuarios.-->
    <di class="container">
        <div class="card col-lg-6">
            <div class="page-header">
                <h4>Registrar usuario.</h4>
            </div>
            <form id="createform" class="form-horizontal" role="form" action="<?php $_SERVER['PHP_SELF'] ?>" method="POST" autocomplete="on">
                <div class="form-group cl-lg-6">
                    <div class="form-group">
                        <input type="text" name="nombre" class="form-control" placeholder="Ingrese el nombre completo" required>
                    </div>
                    <div class="form-group">
                        <input type="text" name="cedula" class="form-control" placeholder="Ingrese el n&uacute;mero de C&eacute;dula" required>
                    </div>
                    <div class="form-group">
                        <select name="genero" id="genero" class="form-control" required>
                            <option value="0">-- Seleccione el Genero --</option>
                            <option value="M">Masculino</option>
                            <option value="F">Femenino</option>   
                        </select>
                    </div>
                    <div class="form-group">
                        <input type="date" name="fecnacimiento" class="form-control" placeholder="Fecha de nacimmiento (YYYY-MM-DD)" required>
                    </div>
                    <div class="form-group">
                        <input type="password" name="password" class="form-control" placeholder="Contrase&ntilde;a" required>
                    </div>
                    <div class="form-group">
                        <input type="text" name="email" class="form-control" placeholder="Correo electronico" required> 
                    </div>
                    <div class="form-group">
                        <select name="perfil" id="perfil" class="form-control" required>
                                <option value="0">-- Selecciona el perfil --</option>
                                <?php


                                $perfiles = "SELECT Id_Perfil,Nombre
                                      FROM perfiles
                                      WHERE Activo = 1";
                                $sqlperfil =  $mysqli->query($perfiles);
                                while ($resultado = mysqli_fetch_array($sqlperfil)){
                                    echo '<option value="'.$resultado[Id_Perfil].'">'.$resultado[Nombre].'</option>';
                                }

                                ?>    
                        </select>
                    </div>
                    <div  class="form-group">
                        <div class="col-sm-12 controls">
                        <button id="submit" type="submit" class="btn btn-success">Registrar</button>&nbsp;
                        <a href="adminusers.php.php" class="btn btn-danger">Cancelar</a>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </di>
    <!-- Fin de formulario de registro-->  
    
    <!-- Tether -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous">
    </script>
    
    <!-- JQuery -->
    <script src="js/jquery.js" charset="utf-8"></script>
    
    <!-- Bootstrap 4 Alpha JS -->
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous">
    </script>   
    <script src="js/bootstrap.min.js" charset="utf-8"></script>
    <script>
    // Initialize tooltip component
    $(function () {
      $('[data-toggle="tooltip"]').tooltip()
    })

    // Initialize popover component
    $(function () {
      $('[data-toggle="popover"]').popover()
    })
    </script>
    
</body>
</html>
