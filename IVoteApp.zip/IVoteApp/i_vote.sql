-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 15-09-2017 a las 23:25:41
-- Versión del servidor: 5.5.16
-- Versión de PHP: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `i_vote`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `candidatos`
--

CREATE TABLE IF NOT EXISTS `candidatos` (
  `Id_Candidato` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Identificación por BD del candidato',
  `Cedula` int(11) NOT NULL COMMENT 'Número de cédula del candidato',
  `Nombre` varchar(100) DEFAULT NULL COMMENT 'Nombre del candidato',
  `Foto` blob COMMENT 'Foto del cnadidato, campo tipo Blob para el manejo de imagenes',
  `Genero` tinytext COMMENT 'Campo tipo tiny text para la descrioción del genero delc andidato como: M y F',
  `Fec_Nacimiento` datetime DEFAULT NULL COMMENT 'Campo tipo DATETIME para la descrición de la fecha de nacimiento del candidato.',
  `Num_candidato` int(11) DEFAULT NULL COMMENT 'Campo tipo INT para la descripción del número de candidato, el cual será unico',
  PRIMARY KEY (`Id_Candidato`),
  UNIQUE KEY `Num_candidato_UNIQUE` (`Num_candidato`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Tabla para el registro de los candidatos' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `elecciones`
--

CREATE TABLE IF NOT EXISTS `elecciones` (
  `Id_Eleccion` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Campo para la identificación por BD de la elección',
  `Fec_ini` datetime DEFAULT NULL COMMENT 'Fecha inicial de la elección',
  `Fec_fin` datetime DEFAULT NULL COMMENT 'Fecha final de la elección',
  `Estado` tinyint(2) DEFAULT NULL COMMENT 'Campo para el registro de la información del estado de la elección',
  PRIMARY KEY (`Id_Eleccion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Tabla para registrar la información de la elección' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `eleccion_cadidato`
--

CREATE TABLE IF NOT EXISTS `eleccion_cadidato` (
  `Id_Elec_cand` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Campo tipo INT para el manejo de la identificación por BD del registro',
  `Candidato_Id` int(11) NOT NULL COMMENT 'Llave foranea con la tabla Candidatos',
  `Eleccion_Id` int(11) NOT NULL COMMENT 'Llave foranea con la tabla de Elecciones',
  `Voto_Id` int(11) NOT NULL COMMENT 'Llave foranea con la tabla de Votos',
  PRIMARY KEY (`Id_Elec_cand`),
  KEY `Candidato_Id` (`Candidato_Id`),
  KEY `Eleccion_Id` (`Eleccion_Id`),
  KEY `Voto_Id` (`Voto_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Tabla para el manejo de los resultados para cada elección' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `perfiles`
--

CREATE TABLE IF NOT EXISTS `perfiles` (
  `Id_Perfil` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Identificación por BD del registro',
  `Nombre` varchar(45) CHARACTER SET latin1 DEFAULT NULL COMMENT 'Nombre asociado al perfil',
  `Activo` tinyint(2) DEFAULT NULL COMMENT 'campo tipo tinyint para el manejo del estado como 1 o 0 ',
  PRIMARY KEY (`Id_Perfil`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Tabla para el manejo de perfiles' AUTO_INCREMENT=7 ;

--
-- Volcado de datos para la tabla `perfiles`
--

INSERT INTO `perfiles` (`Id_Perfil`, `Nombre`, `Activo`) VALUES
(1, 'Administrador', 1),
(2, 'Votante', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `Id_Usuario` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Identificación por BD del usuario',
  `Nombre` varchar(100) DEFAULT NULL COMMENT 'Nombre del usuario',
  `Cedula` int(11) DEFAULT NULL COMMENT 'Cédula del usuario',
  `Genero` char(2) DEFAULT NULL COMMENT 'Campo tipo Tiny text para el manejo del genero como: M y F',
  `Fec_Nacimiento` date DEFAULT NULL COMMENT 'Campo fecha de nacimiento del usuario',
  `Constraseña` varchar(150) DEFAULT NULL COMMENT 'Campo para registrar la contraseña del usuario',
  `Email` varchar(200) NOT NULL,
  `Perfil_Id` int(11) NOT NULL COMMENT 'Llave foranea para asociar el un perfil al usuario',
  PRIMARY KEY (`Id_Usuario`),
  KEY `perfil_idx` (`Perfil_Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Tabla para el registro de los usuarios' AUTO_INCREMENT=4 ;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`Id_Usuario`, `Nombre`, `Cedula`, `Genero`, `Fec_Nacimiento`, `Constraseña`, `Email`, `Perfil_Id`) VALUES
(1, 'Julian Lozano', 1018463748, 'M', '1993-12-10', '1234', 'jalozanog93@hotmail.com', 1),
(2, 'Luisa Fernanda', 121563748, 'F', '1992-10-10', '123456', 'luisa.fernandez@gmail.com', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `votos`
--

CREATE TABLE IF NOT EXISTS `votos` (
  `Id_Voto` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Identificación por BD del voto',
  `Usuario_Id` int(11) DEFAULT NULL COMMENT 'LLave foranea con la tabla Usuarios',
  `Eleccion_Id` int(11) DEFAULT NULL COMMENT 'Llave forane con la tabla de elecciones',
  `Candidato_Id` int(11) DEFAULT NULL COMMENT 'Llave foranea con la tabla de Candidatos',
  `Estado` tinyint(2) DEFAULT NULL COMMENT 'Campo tipo tiny int para el manejo del estado del voto como: 1 y 0',
  `Fecha` datetime DEFAULT NULL COMMENT 'Campo tipo DATETIME para el manejo de la fecha de la votación',
  PRIMARY KEY (`Id_Voto`),
  KEY `Usuario_Id` (`Usuario_Id`),
  KEY `Eleccion_Id` (`Eleccion_Id`),
  KEY `Candidato_Id` (`Candidato_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Tabla para el regsitro de los votos' AUTO_INCREMENT=1 ;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `eleccion_cadidato`
--
ALTER TABLE `eleccion_cadidato`
  ADD CONSTRAINT `eleccion_cadidato_ibfk_1` FOREIGN KEY (`Candidato_Id`) REFERENCES `candidatos` (`Id_Candidato`),
  ADD CONSTRAINT `eleccion_cadidato_ibfk_2` FOREIGN KEY (`Eleccion_Id`) REFERENCES `elecciones` (`Id_Eleccion`),
  ADD CONSTRAINT `eleccion_cadidato_ibfk_3` FOREIGN KEY (`Voto_Id`) REFERENCES `votos` (`Id_Voto`);

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `perfil` FOREIGN KEY (`Perfil_Id`) REFERENCES `perfiles` (`Id_Perfil`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `votos`
--
ALTER TABLE `votos`
  ADD CONSTRAINT `votos_ibfk_1` FOREIGN KEY (`Usuario_Id`) REFERENCES `usuarios` (`Id_Usuario`),
  ADD CONSTRAINT `votos_ibfk_2` FOREIGN KEY (`Eleccion_Id`) REFERENCES `elecciones` (`Id_Eleccion`),
  ADD CONSTRAINT `votos_ibfk_3` FOREIGN KEY (`Candidato_Id`) REFERENCES `candidatos` (`Id_Candidato`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
